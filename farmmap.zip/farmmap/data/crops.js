// SAMPLE DATA: simplified, for demonstration. Based on commonly known major crop-growing states of India.
const CROPS = [
  { id: "wheat", name: "Wheat", emoji: "🌾", category: "Cereal", season: "Rabi (Oct–Mar)",
    info: "India's main winter staple. Needs cool weather while growing and warm, dry weather at harvest." },
  { id: "rice", name: "Rice", emoji: "🍚", category: "Cereal", season: "Kharif (Jun–Nov)",
    info: "Grown in flooded fields with heavy monsoon rain. A staple food for most of India." },
  { id: "maize", name: "Maize", emoji: "🌽", category: "Cereal", season: "Kharif (Jun–Oct)",
    info: "Used as food, poultry feed and in industry. Grows in many soils and climates." },
  { id: "sugarcane", name: "Sugarcane", emoji: "🎋", category: "Cash Crop", season: "Year-round (10–18 months)",
    info: "A long-duration crop that needs plenty of water. Source of sugar, jaggery and ethanol." },
  { id: "cotton", name: "Cotton", emoji: "☁️", category: "Cash Crop", season: "Kharif (Apr–Dec)",
    info: "Main fibre crop. Prefers black soil and warm weather with moderate rainfall." },
  { id: "pulses", name: "Pulses", emoji: "🫘", category: "Pulse", season: "Rabi and Kharif",
    info: "Includes chickpea, pigeon pea, lentil and moong. Rich in protein and good for soil health." }
];
