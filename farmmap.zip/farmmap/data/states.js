// SAMPLE DATA: representative point per state (approximate centre) and its major crops.
const STATES = [
  { name: "Punjab", lat: 30.9, lng: 75.85, crops: ["wheat","rice","cotton","maize"], note: "Known as the granary of India." },
  { name: "Haryana", lat: 29.06, lng: 76.09, crops: ["wheat","rice","cotton","sugarcane"], note: "Strong wheat and rice surplus state." },
  { name: "Uttar Pradesh", lat: 26.85, lng: 80.91, crops: ["wheat","rice","sugarcane","maize","pulses"], note: "Largest sugarcane and wheat producer." },
  { name: "Bihar", lat: 25.6, lng: 85.1, crops: ["rice","wheat","maize","pulses"], note: "Fertile Gangetic plains." },
  { name: "West Bengal", lat: 22.99, lng: 87.85, crops: ["rice","maize","pulses"], note: "One of the top rice producers." },
  { name: "Madhya Pradesh", lat: 23.47, lng: 77.95, crops: ["wheat","pulses","maize","cotton"], note: "Leading pulses producer." },
  { name: "Rajasthan", lat: 26.9, lng: 75.8, crops: ["wheat","pulses","maize","cotton"], note: "Dry-region farming with strong pulses output." },
  { name: "Gujarat", lat: 22.3, lng: 71.2, crops: ["cotton","wheat","pulses","sugarcane"], note: "Top cotton-growing state." },
  { name: "Maharashtra", lat: 19.75, lng: 75.7, crops: ["sugarcane","cotton","pulses","maize","rice"], note: "Major sugarcane and cotton region." },
  { name: "Karnataka", lat: 15.3, lng: 75.7, crops: ["maize","sugarcane","pulses","cotton","rice"], note: "Diverse crops across varied climates." },
  { name: "Andhra Pradesh", lat: 15.9, lng: 79.7, crops: ["rice","cotton","maize","pulses"], note: "Rice bowl of the south." },
  { name: "Telangana", lat: 18.1, lng: 79.0, crops: ["rice","cotton","maize","pulses"], note: "Rice and cotton on black and red soils." },
  { name: "Tamil Nadu", lat: 11.1, lng: 78.65, crops: ["rice","sugarcane","maize","pulses","cotton"], note: "Cauvery delta is a major rice area." },
  { name: "Odisha", lat: 20.95, lng: 85.1, crops: ["rice","pulses","maize"], note: "Rice is the main crop." },
  { name: "Chhattisgarh", lat: 21.3, lng: 81.6, crops: ["rice","maize","pulses"], note: "Called the rice bowl of central India." },
  { name: "Assam", lat: 26.2, lng: 92.9, crops: ["rice","pulses"], note: "Brahmaputra valley rice farming." },
  { name: "Kerala", lat: 10.85, lng: 76.27, crops: ["rice"], note: "Rice in the backwater and paddy lands." },
  { name: "Jharkhand", lat: 23.6, lng: 85.3, crops: ["rice","maize","pulses"], note: "Rain-fed upland farming." },
  { name: "Uttarakhand", lat: 30.07, lng: 79.0, crops: ["wheat","rice","sugarcane"], note: "Terrace farming in the foothills." },
  { name: "Himachal Pradesh", lat: 31.1, lng: 77.17, crops: ["wheat","maize"], note: "Hill farming with wheat and maize." },
  { name: "Jammu & Kashmir", lat: 34.08, lng: 74.8, crops: ["rice","maize"], note: "Valley rice and maize cultivation." }
];
