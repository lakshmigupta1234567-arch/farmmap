# FarmMap – Hackathon Presentation Content

**Project description:** FarmMap is an interactive web dashboard that maps major crops across Indian states, with live weather for each location and simple agricultural insights.

**Problem statement:** Crop, season and weather information is scattered across many sources, so students, farmers and planners find it hard to see "what grows where, and in what conditions" in one place.

**Proposed solution:** One map-first dashboard. Users explore Indian states on an Amazon Location map, filter by crop or category, and see crops, seasons and current weather for the selected state.

**Key features:** Interactive India map with clickable markers · state search · crop category and crop filters · crop information cards · live weather (temperature, humidity, rainfall, wind) · dashboard with totals and crop distribution chart · responsive green/white design with loading and error handling.

**Technology stack:** HTML5, CSS3, JavaScript, MapLibre GL JS, Open-Meteo API.

**AWS services used:** Amazon Location Service (map tiles and styles, accessed with a restricted API key) · AWS Amplify Hosting (HTTPS static hosting).

**Architecture:**
Browser → Amazon Location Service (map) · Browser → Open-Meteo (weather) · Browser ← AWS Amplify Hosting (static files incl. data/*.js)

**Future improvements:** Real government datasets (e.g. Agriculture Ministry open data) stored in Amazon S3 · district-level maps and crop-area polygons · Amazon Location place search · crop recommendations by season and weather · multi-language support (Hindi and regional) · weather forecast and alerts.

**Note for judges:** Crop and state data is sample data and labelled as such in the app.
