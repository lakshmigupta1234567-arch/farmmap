# FarmMap – Intelligent Agricultural Mapping

Static site (HTML, CSS, JavaScript). Map tiles come from **Amazon Location Service**, weather from **Open-Meteo**, hosting on **AWS Amplify Hosting**.
Crop and state data in `data/` is **sample data** for demonstration.

## 1. Create the Amazon Location API key
1. Create/sign in to an AWS account and choose a region (e.g. Asia Pacific (Mumbai) `ap-south-1`; use the region code in `config.js`).
2. Console → **Amazon Location Service** → **API keys** → **Create API key**.
3. Name: `FarmMapKey`. Allowed actions: **Maps** only.
4. Referers: `http://localhost:*` and `http://127.0.0.1:*` (add your Amplify URL later).
5. Create, copy the key, and paste it into `config.js` (`apiKey`).
   The key is public by design; the action and referer limits are what protect it. Never put AWS access keys or secret keys in this project.

## 2. Test locally
Open the folder in VS Code → install **Live Server** → right-click `index.html` → **Open with Live Server**.
Check: map loads, markers click, search/filters work, weather appears, "Show on map" buttons filter.

## 3. Deploy with AWS Amplify Hosting
1. Zip the **contents** of the folder (so `index.html` is at the top level of the zip).
2. Console → **AWS Amplify** → **Create new app** → **Deploy without Git** → upload the zip → Save and deploy.
3. Copy the URL (looks like `https://main.xxxxxxxx.amplifyapp.com`).
4. Go back to Amazon Location → API keys → `FarmMapKey` → add referer `https://main.xxxxxxxx.amplifyapp.com/*` (your real URL).
5. Open the live site and test everything again.
Optional: push to GitHub and connect the repo in Amplify for automatic redeploys.

## 4. Submission checklist
Live URL, GitHub repo link, cover image, short description (see `PRESENTATION.md`), screenshots of map + dashboard.
