// Paste your own values. The API key is restricted in AWS to map actions and your website addresses.
const FARMMAP_CONFIG = {
  region: "ap-south-1",              // change if you created the key in another region
  apiKey: "PASTE_YOUR_API_KEY_HERE",
  mapStyle: "Standard",
  indiaCenter: [78.9629, 22.5937],   // [longitude, latitude]
  indiaZoom: 4
};
