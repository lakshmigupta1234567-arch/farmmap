const $ = (id) => document.getElementById(id);
const cropById = Object.fromEntries(CROPS.map((c) => [c.id, c]));
const state = { q: "", category: "all", crop: "all", selected: null };
let map = null;
const markers = new Map();

/* ---------- Map (Amazon Location Service via MapLibre GL JS) ---------- */
function showMapMsg(text, isError) {
  const el = $("mapMsg");
  el.textContent = text;
  el.classList.toggle("err", !!isError);
  el.classList.remove("hidden");
}

function initMap() {
  if (FARMMAP_CONFIG.apiKey.startsWith("PASTE")) {
    showMapMsg("Add your Amazon Location API key in config.js to load the map. The rest of the dashboard still works.", true);
    return;
  }
  const styleUrl = `https://maps.geo.${FARMMAP_CONFIG.region}.amazonaws.com/v2/styles/${FARMMAP_CONFIG.mapStyle}/descriptor?key=${FARMMAP_CONFIG.apiKey}`;
  try {
    map = new maplibregl.Map({ container: "map", style: styleUrl, center: FARMMAP_CONFIG.indiaCenter, zoom: FARMMAP_CONFIG.indiaZoom, minZoom: 3 });
  } catch (e) {
    showMapMsg("Map failed to start: " + e.message, true);
    return;
  }
  map.addControl(new maplibregl.NavigationControl(), "top-right");
  map.addControl(new maplibregl.ScaleControl({ unit: "metric" }), "bottom-left");
  map.on("load", () => { $("mapMsg").classList.add("hidden"); addMarkers(); applyFilters(); });
  map.on("error", (e) => {
    console.error(e);
    if (!map.loaded()) showMapMsg("Map could not load. Check your API key, region and allowed referers in AWS.", true);
  });
}

function addMarkers() {
  STATES.forEach((s) => {
    const el = document.createElement("div");
    el.className = "marker";
    el.title = s.name;
    el.addEventListener("click", (ev) => { ev.stopPropagation(); selectState(s.name); });
    const m = new maplibregl.Marker({ element: el, anchor: "center" }).setLngLat([s.lng, s.lat]).addTo(map);
    markers.set(s.name, { m, el });
  });
}

/* ---------- Filters and list ---------- */
function matches(s) {
  if (!s.name.toLowerCase().includes(state.q)) return false;
  const list = s.crops.map((id) => cropById[id]);
  if (state.category !== "all" && !list.some((c) => c.category === state.category)) return false;
  if (state.crop !== "all" && !s.crops.includes(state.crop)) return false;
  return true;
}

function applyFilters() {
  const visible = STATES.filter(matches);
  $("count").textContent = `${visible.length} of ${STATES.length} states`;
  const ul = $("stateList");
  ul.innerHTML = "";
  if (!visible.length) ul.innerHTML = '<li class="empty">No states match your filters.</li>';
  visible.forEach((s) => {
    const li = document.createElement("li");
    li.innerHTML = `<span>${s.name}</span><small>${s.crops.length} crops</small>`;
    if (s.name === state.selected) li.classList.add("on");
    li.addEventListener("click", () => selectState(s.name));
    ul.appendChild(li);
  });
  const names = new Set(visible.map((s) => s.name));
  markers.forEach(({ el }, name) => el.classList.toggle("hidden", !names.has(name)));
  document.querySelectorAll(".chip").forEach((c) => c.classList.toggle("on", c.dataset.id === state.crop));
}

function setupFilters() {
  const cats = [...new Set(CROPS.map((c) => c.category))];
  cats.forEach((c) => $("category").insertAdjacentHTML("beforeend", `<option>${c}</option>`));
  const chips = $("chips");
  [{ id: "all", name: "All crops", emoji: "" }, ...CROPS].forEach((c) => {
    const b = document.createElement("button");
    b.className = "chip"; b.dataset.id = c.id; b.textContent = `${c.emoji} ${c.name}`.trim();
    b.addEventListener("click", () => { state.crop = c.id; applyFilters(); });
    chips.appendChild(b);
  });
  $("search").addEventListener("input", (e) => { state.q = e.target.value.trim().toLowerCase(); applyFilters(); });
  $("category").addEventListener("change", (e) => { state.category = e.target.value; applyFilters(); });
}

/* ---------- Selected state details + weather (Open-Meteo) ---------- */
function selectState(name) {
  const s = STATES.find((x) => x.name === name);
  if (!s) return;
  state.selected = name;
  markers.forEach(({ el }, n) => el.classList.toggle("on", n === name));
  if (map) map.flyTo({ center: [s.lng, s.lat], zoom: 6, speed: 0.9 });
  const tags = s.crops.map((id) => { const c = cropById[id]; return `<span class="tag">${c.emoji} ${c.name} · ${c.season.split(" ")[0]}</span>`; }).join("");
  $("detail").innerHTML = `
    <h3>${s.name}</h3><p class="note">${s.note}</p>
    <h4>Major crops</h4>${tags}
    <h4>Current weather</h4><div class="wx" id="wx">Loading weather…</div>
    <p class="note" style="margin-top:12px">Location: ${s.lat.toFixed(2)}°N, ${s.lng.toFixed(2)}°E (approximate state centre)</p>`;
  applyFilters();
  loadWeather(s);
  if (window.innerWidth <= 1000) $("detail").scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function weatherText(code) {
  if (code === 0) return "☀️ Clear sky";
  if (code <= 3) return "⛅ Partly cloudy";
  if (code <= 48) return "🌫️ Fog";
  if (code <= 57) return "🌦️ Drizzle";
  if (code <= 67) return "🌧️ Rain";
  if (code <= 77) return "❄️ Snow";
  if (code <= 82) return "🌧️ Rain showers";
  return "⛈️ Thunderstorm";
}

async function loadWeather(s) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${s.lat}&longitude=${s.lng}&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m&timezone=auto`;
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error("HTTP " + res.status);
    const c = (await res.json()).current;
    if (state.selected !== s.name) return; // user already picked another state
    $("wx").innerHTML = `<div class="t">${c.temperature_2m}°C</div><div>${weatherText(c.weather_code)}</div>
      <div class="row"><span>💧 Humidity</span><b>${c.relative_humidity_2m}%</b></div>
      <div class="row"><span>🌧️ Rainfall</span><b>${c.precipitation} mm</b></div>
      <div class="row"><span>💨 Wind</span><b>${c.wind_speed_10m} km/h</b></div>`;
  } catch (e) {
    console.error(e);
    if (state.selected === s.name) $("wx").innerHTML = '<span class="err-txt">Weather is unavailable right now. Please try again.</span>';
  }
}

/* ---------- Dashboard and crop cards ---------- */
function renderDashboard() {
  const counts = CROPS.map((c) => ({ c, n: STATES.filter((s) => s.crops.includes(c.id)).length })).sort((a, b) => b.n - a.n);
  $("statStates").textContent = STATES.length;
  $("statCrops").textContent = CROPS.length;
  $("statAvg").textContent = (STATES.reduce((t, s) => t + s.crops.length, 0) / STATES.length).toFixed(1);
  $("statTop").textContent = counts[0].c.name;
  const max = counts[0].n;
  $("chart").innerHTML = counts.map(({ c, n }) =>
    `<div class="bar"><span>${c.emoji} ${c.name}</span><div class="track"><div class="fill" style="width:0" data-w="${(n / max) * 100}"></div></div><b>${n}</b></div>`).join("");
  requestAnimationFrame(() => document.querySelectorAll(".fill").forEach((f) => (f.style.width = f.dataset.w + "%")));

  $("cropGrid").innerHTML = CROPS.map((c) => {
    const n = counts.find((x) => x.c.id === c.id).n;
    return `<div class="card crop"><div class="e">${c.emoji}</div><h3>${c.name}</h3>
      <span class="tag">${c.category}</span><span class="tag">${c.season}</span>
      <p>${c.info}</p><p><b>${n}</b> states listed</p>
      <button data-id="${c.id}">Show on map</button></div>`;
  }).join("");
  document.querySelectorAll(".crop button").forEach((b) => b.addEventListener("click", () => {
    state.crop = b.dataset.id; applyFilters();
    $("explore").scrollIntoView({ behavior: "smooth" });
  }));
}

setupFilters();
renderDashboard();
applyFilters();
initMap();
